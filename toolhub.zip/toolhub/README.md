# ToolHub — Web de herramientas online (lista para Vercel + Adsterra)

Sitio 100% estático (HTML/CSS/JS puro). No necesita build ni servidor.

## Estructura
```
/
├─ index.html          → página principal (hub)
├─ assets/style.css    → estilos de todo el sitio
├─ tools/              → 8 herramientas funcionales
│   ├─ imc.html
│   ├─ password.html
│   ├─ palabras.html
│   ├─ unidades.html
│   ├─ edad.html
│   ├─ moneda.html
│   ├─ qr.html
│   └─ porcentaje.html
├─ ads.txt             → editar con tu ID de Adsterra
├─ robots.txt          → editar TU-DOMINIO
├─ sitemap.xml         → editar TU-DOMINIO (reemplazar en todas las líneas)
└─ vercel.json         → config de Vercel
```

## Subir a GitHub + Vercel (paso a paso)
1. Crea un repositorio nuevo en GitHub y sube TODOS estos archivos.
2. Entra a vercel.com → **New Project** → importa tu repo.
3. Framework preset: **Other** (no toca nada más). Deploy.
4. Vercel te da un dominio `xxx.vercel.app`. Ya funciona.
5. (Opcional) Conecta tu dominio propio en Vercel → Settings → Domains.

## Conectar Adsterra
1. Crea cuenta en adsterra.com como **Publisher** y añade tu web.
2. Adsterra te pedirá verificar el sitio. Suele darte una línea para **ads.txt**:
   ábrela y reemplaza el contenido del archivo `ads.txt` por esa línea.
3. Crea unidades de anuncio en tu panel (Banner, Native, Social Bar, Popunder).
4. Cada unidad te da un **snippet**. Pégalo donde dice, en cada archivo HTML:
   - `<!-- ADSTERRA GLOBAL SCRIPT AQUÍ -->` → scripts globales (Social Bar / Popunder). Está en `<head>` de cada página.
   - `<!-- ADSTERRA BANNER -->` → dentro de los bloques `.ad-banner`.
   - `<!-- ADSTERRA 300x250 -->` / `.ad-box` → dentro de los bloques cuadrados.
5. Vuelve a subir los cambios a GitHub. Vercel redepliega solo.

> Consejo: no llenes de anuncios. 1 banner arriba + 1 caja por página es un
> buen equilibrio para que Adsterra apruebe y no espantar visitantes.

## Cosas a editar antes de publicar
- `robots.txt` y `sitemap.xml`: cambia `TU-DOMINIO.com` por tu dominio real.
- `ads.txt`: pon la línea real de Adsterra.
- Textos del footer / nombre "ToolHub" si quieres tu propia marca.

## Notas técnicas
- El conversor de moneda usa `open.er-api.com` (gratis, sin clave, tasas diarias).
- El generador de QR usa `api.qrserver.com` (gratis, sin clave).
- Todo lo demás corre 100% en el navegador. Nada se guarda ni se envía.
